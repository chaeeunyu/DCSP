#include "NIDAQmx.h"
#include "_macro.h"

TaskHandle g_taskAI = 0;
TaskHandle g_taskAO0 = 0;
TaskHandle g_taskAO1 = 0;
int32 sampsPerChanRead;


double TEST_FREQS[N_FREQS] = {
    0.1, 0.2, 0.3, 0.5, 0.7, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0, 15.0
};

// time 관련 변수들 structure로 묶으려다가 갯수가 애매해서 걍 놔뒀어요
// Vcmd, Vc, Vpot, omega, ... 이런애들도 어디는 쓰고 어디는 안쓰는데 있어서 걍 놔둠
// basic variable
double time_init = 0.0;
double time_elapsed = 0.0;
double Vg_offset = 0.0;
double Vcmd = 0.0;
double Vc = 0.0;
double Vg = 0.0;
double Vpot = 0.0;
double omega = 0.0;
double readArr[2] = { 0.0 };
int nStep = 0;
int count = 0;

/* Sweep (reused per step) */
double voltSeq[N_STEPS_MAX] = { 0 };

// 버퍼도 structure 만들려다가 걍 놔둠. 한개가지고 돌려쓰면 메모리 절약될거같아요
/* Triangle / Sine shared (size = TRI_N_MAX) */
double buftime[BUF_SIZE];
double bufVcmd[BUF_SIZE];
double bufVc[BUF_SIZE];
double bufVg[BUF_SIZE];
double bufVpot[BUF_SIZE];
double bufomega[BUF_SIZE];
double bufomega_target[BUF_SIZE];


/* Bode results */
double bode_result_freq[N_FREQS];
double bode_result_gain[N_FREQS];
double bode_result_phase[N_FREQS];


/*Function Declarations*/
double GetWindowTime(void);
void   memorySet(void);
void   BusyWait_ms(double ms);
void   WaitNextSample(void);
int    IsEmergencyStop(void);

void   DAQ_Init(void);
void   DAQ_Cleanup(void);
void   DAQ_ReadSample(void);
void   motor_power(float64 onoff, double voltage);

double CalculateGyroBias(int nSamples);
int    BuildVoltageSequence(void);
void   RunSweep(void);
double InverseMap(double vcmd_ref);
double Triangle_cmd(double t);
void   RunWaveVerify(int mode);

void   RunBode(void); // c코드에서는 freq sweep (raw data)만 뽑고 DFT나 mag/phase 계산은 매트랩에서 하는게 더 쉬울 것 같아요
void   ComputeGainPhase(double* vcmd_buf, double* omega_buf, int N, double freq, double dt, double* gain_out, double* phase_out);
static int GetNCycles(double freq);


void main(void)
{
    int mode = 0;

    printf("Press [Enter] to start the program.... \n\n");
    getchar();

    printf("\n[DAQ Initializing...]\n");
    DAQ_Init();
    // ------ Initialize: switch OFF, motor neutral -------------------
    motor_power(ON, NEUTRAL);

    printf("[Step 0] Confirm motor is stopped, then press [Enter].\n");
    getchar();

    // ------ 0. Calculate Gyro Bias ----------------------------------
    Vg_offset = CalculateGyroBias(N_BIAS);

    do {
        printf("============================================================\n");
        printf("  Hello, are you ready?\n");
        printf("============================================================\n");
        printf("  1. Voltage Sweep\n");
        printf("  2. Triangle Wave Verify\n");
        printf("  3. Sine Wave Verify\n");
        printf("  4. Frequency Response (Bode Plot)\n");
        printf("  0. Exit\n");
        printf("============================================================\n");
        printf("Select mode > ");

        scanf("%d", &mode);

        switch (mode)
        {
            case EXIT:
                break;

            case VOLTAGE_SWEEP:
                RunSweep();
                break;
            case FREQ_SWEEP:
                RunBode();
                break;

            case SINE_VALIDATION:
                RunWaveVerify(MODE_SINE);
                break;

            case TRI_VALIDATION:
                RunWaveVerify(MODE_TRI);
                break;

            default:
                printf("[Error] Invalid mode: %d\n", mode);
                break;
        }
    } while (mode >= 1 && mode <= 4);


    printf("[DAQ Cleaning up...]\n");
    DAQ_Cleanup();
    printf("\nProgram finished. Press [Enter] to exit.\n");
    getchar();
}


/* Returns current time [ms] */
double GetWindowTime(void)
{
    LARGE_INTEGER liCounter, liFrequency;
    QueryPerformanceCounter(&liCounter);
    QueryPerformanceFrequency(&liFrequency);
    return (liCounter.QuadPart / (double)(liFrequency.QuadPart) * 1000.0);
}

void memorySet(void)
{
    memset(buftime, 0, sizeof(buftime));
    memset(bufVcmd, 0, sizeof(bufVcmd));
    memset(bufVg, 0, sizeof(bufVg));
    memset(bufVc, 0, sizeof(bufVc));
    memset(bufVpot, 0, sizeof(bufVpot));
    memset(bufomega, 0, sizeof(bufomega));
    memset(bufomega_target, 0, sizeof(bufomega_target));
}


void BusyWait_ms(double ms)
{
    double time_start = 0.0;
    time_start = GetWindowTime();
    while (GetWindowTime() - time_start < ms);
}

/* Wait until the next sampling interval (based on time_start[ms] and completed sample count) */
void WaitNextSample(void)
{
    double target_ms = count * SAMPLING_TIME * 1000.0;
    while (GetWindowTime() - time_init < target_ms); // [ms]
}

/* Check spacebar emergency stop */
int IsEmergencyStop(void)
{
    return (GetAsyncKeyState(VK_SPACE) & 0x8000) ? 1 : 0;
}


double CalculateGyroBias(int nSamples)
{
    double y_bar = 0.0;
    double y_k = 0.0;
    memset(readArr, 0, sizeof(readArr));
    
    printf("[Gyro Bias] Collecting %d samples...\n", nSamples);
    for (int k = 1; k <= nSamples; k++) {
        READ_DATA(readArr);
        y_k = readArr[0];
        y_bar = (1.0 - 1.0 / k) * y_bar + (1.0 / k) * y_k;
        BusyWait_ms(5.0);
    }
    printf("[Gyro Bias Done] Vg_offset = %.6f V\n\n", y_bar);
    return y_bar;
}

void motor_power(float64 onoff, double voltage) {

    DAQmxWriteAnalogScalarF64(g_taskAO0, 1, 10.0, onoff, NULL);
    DAQmxWriteAnalogScalarF64(g_taskAO1, 1, 10.0, voltage, NULL);
}

void DAQ_Init(void)
{
    DAQmxCreateTask("", &g_taskAI);
    DAQmxCreateTask("", &g_taskAO0);
    DAQmxCreateTask("", &g_taskAO1);

    DAQmxCreateAIVoltageChan(g_taskAI, "Dev3/ai2, Dev3/ai3", "", DAQmx_Val_RSE, -10.0, 10.0, DAQmx_Val_Volts, "");
    DAQmxCreateAOVoltageChan(g_taskAO0, "Dev3/ao0", "", 0.0, 5.0, DAQmx_Val_Volts, "");
    DAQmxCreateAOVoltageChan(g_taskAO1, "Dev3/ao1", "", 0.0, 5.0, DAQmx_Val_Volts, "");

    DAQmxStartTask(g_taskAI);
    DAQmxStartTask(g_taskAO0);
    DAQmxStartTask(g_taskAO1);

}

void DAQ_Cleanup(void)
{
    motor_power(OFF, NEUTRAL);

    DAQmxStopTask(g_taskAI);  DAQmxClearTask(g_taskAI);
    DAQmxStopTask(g_taskAO0); DAQmxClearTask(g_taskAO0);
    DAQmxStopTask(g_taskAO1); DAQmxClearTask(g_taskAO1);

}

/* Read 1 sample from DAQ */
void DAQ_ReadSample(void)
{
    memset(readArr, 0, sizeof(readArr));
    Vg = 0, Vpot = 0, omega = 0;
    int32 err = 0;
    err = READ_DATA(readArr);
    if (err != 0) {
        char errBuff[2048];
        DAQmxGetExtendedErrorInfo(errBuff, 2048);
        printf("[DAQ Read Error] %s\n", errBuff);
    }
    Vg = readArr[0];
    Vpot = readArr[1];
    omega = K_GIMBAL * (Vg - Vg_offset);
}


int BuildVoltageSequence(void)
{
    // initialize
    double deltas[N_STEPS_MAX] = { 0.0 };
    int    nDeltas = 0;
    double vCW = 0.0;
    double vCCW = 0.0;

    for (int i = 1; i <= 50; i++)  deltas[nDeltas++] = i * 0.01;        /* deadzone */
    for (int i = 1; i <= 39; i++)  deltas[nDeltas++] = 0.50 + i * 0.05; /* outer */
    deltas[nDeltas++] = 2.50;

    int nSteps = 0;
    for (int i = 0; i < nDeltas; i++) {
        vCW = 2.5 + deltas[i]; if (vCW > 5.0) vCW = 5.0;
        vCCW = 2.5 - deltas[i]; if (vCCW < 0.0) vCCW = 0.0;
        voltSeq[nSteps++] = vCW;   /* CW  (even index) */
        voltSeq[nSteps++] = vCCW;  /* CCW (odd index)  */
    }
    return nSteps;
}


void RunSweep(void)
{
    // initialize
    double omega_sum = 0;
    double omega_i = 0;
    const char* dir;
    char filename[256];
    nStep = BuildVoltageSequence();
    memorySet();
    
    char* outputDir = "motor_sweep_data";
    _mkdir(outputDir);

    printf("============================================================\n");
    printf("  [MODE 1] Voltage Sweep (%d steps)\n", N_STEPS_MAX);
    printf("  Deadzone 2.0~3.0V -> 0.01V step\n");
    printf("  Outer    0.0~2.0V, 3.0~5.0V -> 0.05V step\n");
    printf("  Hold time : %.1f sec,  K_gimbal = %.4f (rad/s)/V\n", HOLD_TIME, K_GIMBAL);
    printf("============================================================\n\n");

    printf("[Step 1] Turn on gimbal switch, then press [Enter].\n\n");
    printf("  * Emergency stop: Spacebar\n\n");
    if (IsEmergencyStop()) {
        motor_power(OFF, NEUTRAL);
        return;
    }

    // apply voltage, Vcmd
    for (int step = 0; step < nStep && !IsEmergencyStop; step++)
    {
        Vcmd = voltSeq[step];
        dir = (step % 2 == 0) ? "CW" : "CCW";

        printf("-----------------------------------------\n");
        printf("[Step %3d/%d]  Vcmd = %.2f V  (%s)\n",
            step + 1, nStep, Vcmd, dir);

        /* Apply voltage */
        motor_power(ON, Vcmd);

        time_init = GetWindowTime();
        count = 0;
       
                        
        while (1)
        {
            if (IsEmergencyStop()) {
                printf("\n[EMERGENCY STOP] Spacebar pressed!\n");
                break;
            }

            // apply every voltage for each 4s
            time_elapsed = (GetWindowTime() - time_init) * 0.001;
            if (time_elapsed >= HOLD_TIME) break;

            DAQ_ReadSample();

            if (count < N_HOLD) {
                buftime[count] = time_elapsed;
                bufVcmd[count] = Vcmd;
                bufVg[count] = Vg;
                bufVpot[count] = Vpot;
                bufomega[count] = omega;
                count++;
            }

            /* Wait for next sampling interval */
            WaitNextSample();
        }
        
        /* Save to file */
        if (count > 0) {
            sprintf(filename, "%s/step_%03d_V%.2f_%s.out", outputDir, step + 1, Vcmd, dir);
            FILE* pFile = fopen(filename, "w+t");
            if (pFile) {
                fprintf(pFile, "%% Sweep Step %d/%d  Vcmd=%.4fV  %s \n", step + 1, N_STEPS_MAX, Vcmd, dir);
                fprintf(pFile, "%% Vg_offset=%.6fV  K_gimbal=%.6f\n\n", Vg_offset, K_GIMBAL);
                fprintf(pFile, "Time[s]              Vcmd[V]              Vg_raw[V]            Pot[V]             Omega[rad/s]\n");
                for (int i = 0; i < count; i++)
                    fprintf(pFile, "%20.10f %20.10f %20.10f %20.10f %20.10f\n",
                        buftime[i], bufVcmd[i], bufVg[i], bufVpot[i], bufomega[i]);
                fclose(pFile);
                printf("  -> Saved: %s  (%d samples)\n", filename, count);
            }
            else
            {
                printf("  !! File open failed: %s\n", filename);
            }
        }

        /* Neutral pause between steps */
        if (!IsEmergencyStop && step < N_STEPS_MAX - 1) {
            motor_power(ON, NEUTRAL);
            BusyWait_ms(1000.0);
        }
    }

    motor_power(ON, NEUTRAL);
    printf("\n[MODE 1 Done] Output folder: %s\n\n", outputDir);
}

double Triangle_cmd(double t)
{
    double phase = 0;
    phase = fmod(t, TRI_PERIOD) / TRI_PERIOD;
    if (phase < 0.25) return  TRI_AMP * (4.0 * phase);
    else if (phase < 0.75) return  TRI_AMP * (2.0 - 4.0 * phase);
    else                   return  TRI_AMP * (4.0 * phase - 4.0);
}

double InverseMap(double vcmd_ref)
{
    double omega_target = K_LIN * vcmd_ref;
    double Vc = 2.5;

    if (omega_target > DEAD_THRESH)
    {
        /* CW branch */
        double a = P_CW_A, b = P_CW_B, c = P_CW_C - omega_target;
        double disc = b * b - 4.0 * a * c;
        if (disc >= 0.0) {
            double r1 = (-b + sqrt(disc)) / (2.0 * a);
            double r2 = (-b - sqrt(disc)) / (2.0 * a);
            int r1ok = (r1 >= 2.5) && (r1 <= 5.0);
            int r2ok = (r2 >= 2.5) && (r2 <= 5.0);
            if (r1ok && r2ok) Vc = (r1 < r2) ? r1 : r2;
            else if (r1ok)         Vc = r1;
            else if (r2ok)         Vc = r2;
            else                   Vc = 2.5;
        }
    }
    else if (omega_target < -DEAD_THRESH)
    {
        /* CCW branch */
        double a = P_CCW_A, b = P_CCW_B, c = P_CCW_C - omega_target;
        double disc = b * b - 4.0 * a * c;
        if (disc >= 0.0) {
            double r1 = (-b + sqrt(disc)) / (2.0 * a);
            double r2 = (-b - sqrt(disc)) / (2.0 * a);
            int r1ok = (r1 >= 0.0) && (r1 <= 2.5);
            int r2ok = (r2 >= 0.0) && (r2 <= 2.5);
            if (r1ok && r2ok) Vc = (r1 < r2) ? r1 : r2;
            else if (r1ok)         Vc = r1;
            else if (r2ok)         Vc = r2;
            else                   Vc = 2.5;
        }
    }


    if (Vc < 0.0) Vc = 0.0;
    if (Vc > 5.0) Vc = 5.0;
    return Vc;
}

void RunWaveVerify(int mode)
{
    double T_total = 0.0;
    memorySet();

    printf("[Step 1] Turn on gimbal switch, then press [Enter].\n");
    getchar();
    motor_power(ON, NEUTRAL);
    GetAsyncKeyState(VK_SPACE);

    T_total = (mode == MODE_SINE) ? SINE_T_TOTAL : TRI_T_TOTAL;
    time_init = GetWindowTime();
    time_elapsed = 0.0;
    count = 0;

    // main loop
    while (1)
    {
        if (IsEmergencyStop()) break;

        time_elapsed = (GetWindowTime() - time_init) * 0.001;
        if (time_elapsed >= T_total) break;

        Vcmd = (mode == MODE_SINE) ? SINE_CMD(time_elapsed) : Triangle_cmd(time_elapsed);
        Vc = InverseMap(Vcmd);

        // apply voltage Vc
        motor_power(ON, Vc);
        DAQ_ReadSample();

        if (count < BUF_SIZE) {
            buftime[count] = time_elapsed;
            bufVcmd[count] = Vcmd;
            bufVc[count] = Vc;
            bufVg[count] = Vg;
            bufVpot[count] = Vpot;
            bufomega[count] = omega;
            count++;
        }

        WaitNextSample();
    }

    motor_power(ON, NEUTRAL);

    // save files
    char filename[256];
    if (mode == MODE_SINE)
        sprintf(filename, "sine_A%.2f_F%.4f.out", SINE_AMP, SINE_FREQ);
    else
        sprintf(filename, "tri_A%.1f_T%.0f.out", TRI_AMP, TRI_PERIOD);

    FILE* fp = fopen(filename, "w");
    if (!fp) { printf("[Error] Cannot open: %s\n", filename); return; }

    fprintf(fp, "%% K_lin=%.6f  p_cw=[%.6f %.6f %.6f]  p_ccw=[%.6f %.6f %.6f]\n",
        K_LIN, P_CW_A, P_CW_B, P_CW_C, P_CCW_A, P_CCW_B, P_CCW_C);
    fprintf(fp, "Time[s]              Vcmd[V]              Vc[V]"
        "                Vg[V]                Pot[V]"
        "               Omega[rad/s]\n");

    for (int i = 0; i < count; i++)
        fprintf(fp, "%20.10f %20.10f %20.10f %20.10f %20.10f %20.10f\n",
            buftime[i], bufVcmd[i], bufVc[i], bufVg[i], bufVpot[i], bufomega[i]);

    fclose(fp);
    printf("[Saved] %s  (%d samples)\n", filename, count);
} 
// good


void ComputeGainPhase(double* vcmd_buf, double* omega_buf, int N, double freq, double dt, double* gain_out, double* phase_out)
{
    // initialize
    double w = 2.0 * UNIT_PI * freq;
    double re_x = 0.0, im_x = 0.0;
    double re_y = 0.0, im_y = 0.0;
    double t = 0.0;
    double cos_wt = 0.0;
    double sin_wt = 0.0;
    double mag_x = 0.0;
    double mag_y = 0.0;

    for (int k = 0; k < N; k++) {
        t = k * dt;
        cos_wt = cos(w * t);
        sin_wt = sin(w * t);
        re_x += vcmd_buf[k] * cos_wt;
        im_x -= vcmd_buf[k] * sin_wt;
        re_y += omega_buf[k] * cos_wt;
        im_y -= omega_buf[k] * sin_wt;
    }
    re_x *= (2.0 / N); im_x *= (2.0 / N);
    re_y *= (2.0 / N); im_y *= (2.0 / N);

    mag_x = sqrt(re_x * re_x + im_x * im_x);
    mag_y = sqrt(re_y * re_y + im_y * im_y);

    *gain_out = (mag_x > 1e-9) ? (mag_y / mag_x) : 0.0;
    *phase_out = (atan2(im_y, re_y) - atan2(im_x, re_x)) * 180.0 / UNIT_PI;
    while (*phase_out > 180.0) *phase_out -= 360.0;
    while (*phase_out < -180.0) *phase_out += 360.0;
}

/* Returns number of cycles based on frequency (adaptive) */
static int GetNCycles(double freq)
{
    if (freq < FREQ_THR_LOW) return N_CYCLES_LOW;
    else if (freq < FREQ_THR_MID) return N_CYCLES_MID;
    else                          return N_CYCLES_HIGH;
}


void RunBode(void)
{
    // initialize
    double t = 0;
    double gain = 0.0;
    double phase = 0.0;
    double gain_dB = 0.0;
    double total_est = 0.0;
    double freq = 0.0;
    int    n_cycles = 0.0;
    double T_total = 0.0;
    double T_skip = 0.0;
    int    N_total = 0.0;
    int    N_skip = 0.0;
    int    N_valid = 0.0;
    char fname[256];
    char fname_bode[256];

    const char* outputDir = "bode_data";
    _mkdir(outputDir);

    /* Estimated total experiment time */
    for (int i = 0; i < N_FREQS; i++)
        total_est += (1.0 / TEST_FREQS[i]) * GetNCycles(TEST_FREQS[i]);

    printf("============================================================\n");
    printf("  [MODE 4] Frequency Response (Bode Plot)\n");
    printf("  Sine amplitude : %.2f V  (Vcmd)\n", BODE_SINE_AMP);
    printf("  Frequencies    : %d points  (0.1 ~ 15 Hz)\n", N_FREQS);
    printf("  Cycles/freq    : adaptive (f<%.1f: %d, f<%.1f: %d, else: %d)\n",
        FREQ_THR_LOW, N_CYCLES_LOW, FREQ_THR_MID, N_CYCLES_MID, N_CYCLES_HIGH);
    printf("  Skip cycles    : %d\n", N_SKIP_CYCLES);
    printf("  Estimated time : ~%.0f sec (%.1f min)\n", total_est, total_est / 60.0);
    printf("============================================================\n\n");

    printf("[Step 1] Turn on gimbal switch, then press [Enter].\n\n");
    getchar();
    GetAsyncKeyState(VK_SPACE);

    motor_power(ON, NEUTRAL);

    /* Frequency sweep loop */
    for (int fi = 0; fi < N_FREQS && !IsEmergencyStop; fi++)
    {
        freq = TEST_FREQS[fi];
        n_cycles = GetNCycles(freq);
        T_total = (1.0 / freq) * n_cycles;
        T_skip = (1.0 / freq) * N_SKIP_CYCLES;
        N_total = (int)(T_total * SAMPLING_FREQ);
        N_skip = (int)(T_skip * SAMPLING_FREQ);
        N_valid = N_total - N_skip;
        memorySet();

        /* Guard against buffer overflow or invalid skip */
        if (N_skip >= N_total || N_total > BODE_N_MAX) {
            printf("[WARN] f=%.1f Hz skipped (buffer overflow or N_skip >= N_total)\n", freq);
            continue;
        }

        printf("------------------------------------------------------------\n");
        printf("[%d/%d] f=%.1fHz | cycles=%d | T=%.1fs | N_valid=%d\n",
            fi + 1, N_FREQS, freq, n_cycles, T_total, N_valid);

        /* Sine wave output and data collection */
        time_init = GetWindowTime();

        for (count = 0; count < N_total && !IsEmergencyStop; count++)
        {
            if (IsEmergencyStop()) {
                printf("\n[EMERGENCY STOP] Spacebar pressed!\n");
                break;
            }
                        
            t = count* SAMPLING_TIME;
            Vcmd = BODE_SINE_AMP * sin(2.0 * UNIT_PI * freq * t);
            Vc = InverseMap(Vcmd);

            motor_power(ON, Vc);

            DAQ_ReadSample();

            buftime[count] = t;
            bufVcmd[count] = Vcmd;
            bufVc[count] = Vc;
            bufomega[count] = K_GIMBAL * (readArr[0] - Vg_offset);

            WaitNextSample();
        }

        motor_power(ON, NEUTRAL) ;

        /* DFT after excluding transient (N_skip samples) */
        ComputeGainPhase(bufVcmd + N_skip, bufomega + N_skip, N_valid, freq, SAMPLING_TIME, &gain, &phase);
        gain_dB = 20.0 * log10(gain > 1e-9 ? gain : 1e-9);

        bode_result_freq[fi] = freq;
        bode_result_gain[fi] = gain_dB;
        bode_result_phase[fi] = phase;

        printf("  -> Gain = %.4f (%.2f dB)  |  Phase = %.2f deg\n",
            gain, gain_dB, phase);

        /* Save raw data */
        sprintf(fname, "%s/raw_f%.2fHz.out", outputDir, freq);
        FILE* fp = fopen(fname, "w+t");
        if (fp) {
            fprintf(fp, "%% f=%.2fHz  gain=%.4f(%.2fdB)  phase=%.2fdeg\n",
                freq, gain, gain_dB, phase);
            fprintf(fp, "Time[s]              Vcmd[V]              "
                "Vc[V]                Omega[rad/s]\n");
            for (int k = 0; k < N_total; k++)
                fprintf(fp, "%20.10f %20.10f %20.10f %20.10f\n",
                    buftime[k], bufVcmd[k],
                    bufVc[k], bufomega[k]);
            fclose(fp);
        }
        else
        {
            printf("  !! File open failed: %s\n", fname);
        }

        /* Neutral pause between frequencies */
        BusyWait_ms(1000.0);
    }

    motor_power(ON, NEUTRAL);

    /* Save Bode plot result */
    sprintf(fname_bode, "%s/bode_result.out", outputDir);
    FILE* fp_bode = fopen(fname_bode, "w+t");
    if (fp_bode) {
        fprintf(fp_bode, "%% Bode Plot  Amp=%.2fV  Vcmd->omega\n"
             "Freq[Hz]             Gain[dB]             Phase[deg]\n", BODE_SINE_AMP);
        for (int i = 0; i < N_FREQS; i++)
            fprintf(fp_bode, "%20.10f %20.10f %20.10f\n", bode_result_freq[i], bode_result_gain[i], bode_result_phase[i]);
            fclose(fp_bode);
            printf("\n[Saved] %s\n", fname_bode);
    }
    else
    {
        printf("  !! File open failed: %s\n", fp_bode);
    }
    printf("\n[MODE 4 Done] Output folder: %s\n\n", outputDir);
}

