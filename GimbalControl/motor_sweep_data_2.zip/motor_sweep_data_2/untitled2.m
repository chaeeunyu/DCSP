clear all; close all; clc;

% FileType을 텍스트로 명확히 지정하고, NumHeaderLines 옵션을 사용
% data = readmatrix("step_001_V2.51_CW.out", 'FileType', 'text', 'NumHeaderLines', 8);

% 폴더 내 모든 step_XXX_... .out 파일 목록을 가져옴
file_structs = dir('step_*.out');
all_data = cell(length(file_structs), 1);

for i = 1:length(file_structs)
    filename = file_structs(i).name; % 실제 파일 이름을 그대로 가져옴
    raw = readmatrix(filename, 'fileType', 'text', 'HeaderLines', 8);
    all_data{i} = raw;
end
